package com.example.yassine.formes;

import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.widget.Toast;

import java.util.Random;

/**
 * Created by YASSINE on 20/12/2017.
 */

public class FormeView extends View {

    private String typeForme;
    private float x1 , y1;
    private float x2, y2;

    private Paint paint;
    public FormeView(Context context, String typeForme) {
        super(context);
        this.typeForme = typeForme;
        paint = new Paint();
        paint.setColor(Color.GREEN);
    }

    public FormeView(Context context, String typeForme, float x1, float y1, float x2, float y2 , String color) {
        super(context);
        this.typeForme = typeForme;
        this.x1=x1;
        this.y1=y1;
        this.x2=x2;
        this.y2=y2;
        paint = new Paint();
        if(color.equals("GREEN"))
            paint.setColor(Color.GREEN);
        else if(color.equals("RED"))
            paint.setColor(Color.RED);
        if(color.equals("BLUE"))
            paint.setColor(Color.BLUE);
        if(color.equals("WHITE"))
            paint.setColor(Color.WHITE);

    }


    @Override
    protected void onDraw(Canvas canvas) {
        float r;
        switch (typeForme) {
            case "LINE" :
                //paint.setColor(Color.BLUE);
                paint.setStrokeWidth(10);
                canvas.drawLine(x1 ,y1 , x2 , y2 ,paint);
                break;
            case "CIRCLE" :
                //paint.setColor(Color.GREEN);
                r= (float) Math.sqrt(Math.abs((y2-y1)*(y2-y1)-(x2-x1)*(x2-x1)));
                canvas.drawCircle(x1, y1,r, paint);
                break;
            case "RECTANGLE" :
                //paint.setColor(Color.RED);
                canvas.drawRect(x1,y1,x2,y2,paint);
                break;

            case "TRIANGLE" :
                //paint.setColor(Color.BLACK);
                paint.setStrokeWidth(10);
                canvas.drawLine(x1 , y1 , x1 + 400,y1 + 200 , paint);
                canvas.drawLine(x1+400 , y1+200 , x1+100,y1 + 300 , paint);
                canvas.drawLine(x1+100 , y1+300 ,x1,y1, paint);
                break;
        }

    }

}