package com.example.yassine.formes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    //View MyView
    String forme="";
    Button rect,circle,line,clear;
    RelativeLayout layout;
    float x1 = 0, x2 = 0 , y1 = 0 , y2 = 0;
    int nbreClick = 0;
    String typeView = "";
    String color = "WHITE";
    //int x=0,y=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        setContentView(R.layout.activity_main);

        layout =(RelativeLayout)findViewById(R.id.principal_layout);

        rect=(Button)findViewById(R.id.rect);
        circle=(Button)findViewById(R.id.circle);
        line=(Button)findViewById(R.id.line);
        clear=(Button)findViewById(R.id.clear);

        rect.setOnClickListener(listener);
        circle.setOnClickListener(listener);
        line.setOnClickListener(listener);
        clear.setOnClickListener(listener);


        Spinner spinner = (Spinner) findViewById(R.id.spinner);

        spinner.setOnItemSelectedListener(this);

        List<String> shapes = new ArrayList<>();
        shapes.add("RED");
        shapes.add("GREEN");
        shapes.add("BLUE");

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this , R.array.shapes_array , android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(adapter);

    }
    View.OnClickListener listener=new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Log.e("ddd" , "lis");
            int id;


            id=view.getId();
            Log.e("TAG" , "click");
            layout.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    Log.e("TAG", "Toouch_");
                    float xClic = motionEvent.getX();
                    float yClic = motionEvent.getY();
                    Log.e("TAG", "Toouch");
                    if (nbreClick == 0) {
                        x1 = xClic;
                        y1 = yClic;
                        nbreClick++;
                    } else if (nbreClick == 1) {
                        x2 = xClic;
                        y2 = yClic;
                        nbreClick = 0;
                        if(typeView.equals("LINE")) {
                            layout.addView(new FormeView(MainActivity.this, "LINE", x1, y1, x2, y2 , color));
                            layout.setOnTouchListener(null);
                        }
                        if(typeView.equals("RECTANGLE")) {
                            layout.addView(new FormeView(MainActivity.this,"RECTANGLE",x1, y1, x2, y2 , color));
                            layout.setOnTouchListener(null);
                        }
                        if(typeView.equals("CIRCLE")) {
                            layout.addView(new FormeView(MainActivity.this,"CIRCLE",x1, y1, x2, y2 , color));
                            layout.setOnTouchListener(null);
                        }
                    }
                    return false;
                }


            });
            switch (id)
            {
                case R.id.line:
                    typeView = "LINE";
                    break;
                case R.id.rect:
                    Log.e("ddd" , "rect");
                    typeView="RECTANGLE";
                    break;
                case R.id.circle:
                    typeView="CIRCLE";
                    break;
                case R.id.clear:
                    layout.removeAllViews();
                    break;
            }
        }
    };

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

        String itemSelected = adapterView.getItemAtPosition(i).toString();
        Log.d("test", "largeur : " + itemSelected);
        color = itemSelected;
        Log.e("color" , itemSelected);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}


