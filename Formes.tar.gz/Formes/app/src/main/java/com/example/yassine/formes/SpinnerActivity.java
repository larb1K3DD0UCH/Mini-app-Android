package com.example.yassine.formes;

import android.app.Activity;
import android.widget.AdapterView;
import android.widget.Spinner;

/**
 * Created by YASSINE on 21/12/2017.
 */
public class SpinnerActivity extends Activity {
    Spinner spinner;

}
